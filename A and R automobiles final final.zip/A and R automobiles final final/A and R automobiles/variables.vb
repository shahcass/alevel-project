﻿' All the strutctures, arrays and variables are declared
Module variables
    Public Structure Staffdetails
        Public ID As String
        Public FirstName As String
        Public Surname As String
        Public phonenum As String
        Public DOB As String
        Public password As String
    End Structure
    Public Structure vehicledetails
        Public regnumber As String
        Public make As String
        Public model As String
        Public colour As String
        Public mileage As String
        Public price As String
        Public problems As String
        Public owners As String
        Public fueltype As String
        Public transmission As String
        Public enginesize As Single

    End Structure
    Public Structure saledetails
        Public staffID As String
        Public customerID As String
        Public regnumber As String
        Public vehicleprice As Integer
        Public datebooked As String
        Public paymentmethod As String
        Public paymenttype As String
        Public priceboughtfor As Integer
        Public profitmade As Integer
    End Structure
    Public Structure rentalvehicledetails
        Public regnumber As String
        Public make As String
        Public model As String
        Public mileage As Integer
        Public colour As String
        Public fueltype As String
        Public transmission As String
    End Structure
    Public Structure rentaldetails
        Public rentalID As String
        Public customerID As String
        Public regnumber As String
        Public dailyprice As Integer
        Public datebooked As String
        Public daysrented As Integer
        Public total As Integer
        Public returndate As String
    End Structure

    Public stringline As String
    Public staff As New Staffdetails
    Public staffrecords(5) As String
    Public customerrecords(6) As String
    Public sale As New saledetails
    Public salerecords(7)
    Public vehicle As vehicledetails
    Public vehiclerecords(10) As String
    Public rentalrecords(7) As String
    Public bookingdate As String
    Public rental As rentaldetails
    Public rentalvehicles As rentalvehicledetails
    Public stockline(10) As String
    Public rentalvehiclerecords(5)
    Public line(10) As String
    Public item As String
    Public stock As ListViewItem
    Public customers(6, 35)


    Function intcheck(ByVal input As String) As Boolean ' this functions checks if the field is a integer,as it converts the inputted text to a integer if it converts to integer then it passes the check.
        Try
            Convert.ToInt32(input)
            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function


End Module



