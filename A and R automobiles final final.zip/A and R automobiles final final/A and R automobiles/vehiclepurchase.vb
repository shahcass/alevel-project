﻿Imports System.IO
Public Class vehiclepurchase
    Private Sub vehichleform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim vehilce As New A_and_R_automobiles.vehicledetails
        If Dir$("Vehicledetails.txt") = "" Then
            Dim vehiclewriter As New StreamWriter(Application.StartupPath & "\Vehicledetails.txt", True)
        End If
    End Sub

    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click

        Dim vehiclewriter As New System.IO.StreamWriter(Dir$("vehicledetails.txt"), True)
        If txtregistrationnum.Text = "" Then
            MsgBox("Please enter a registration number") ' this checks if the registration number is left blank, if it is  the text box becomes red.
            txtregistrationnum.BackColor = Color.Red
        Else
            vehicle.regnumber = UCase(txtregistrationnum.Text)
            txtregistrationnum.BackColor = Color.Green
        End If

        If txtmodel.Text = "" Then ' this checks if the vehicle model is left blank, if it is  the text box becomes red.
            MsgBox("Please enter vehicle model")
            txtmodel.BackColor = Color.Red
        Else
            vehicle.model = UCase(txtmodel.Text)
            txtmodel.BackColor = Color.Green
        End If

        If txtmake.Text = "" Then
            MsgBox("Please enter vehicle make") ' this checks if the vehicle make is left blank, if it is the text box becomes red.
            txtmake.BackColor = Color.Red
        Else
            vehicle.make = txtmake.Text
            txtmake.BackColor = Color.Green
        End If



        If txtmileage.Text = "" Then ' this checks if the mileage is left blank, if it is  the text box becomes red.
            MsgBox("Please enter vehicle mileage")
            txtmileage.BackColor = Color.Red
        ElseIf txtmileage.Text <> "" Then ' if the mileage isn't blank the program checks if it is a integer, if it is not the the text box becomes red.
            If intcheck(txtmileage.Text) Then
                txtmileage.BackColor = Color.Green
                vehicle.mileage = txtmileage.Text
            Else
                txtmileage.BackColor = Color.Red
                MsgBox("ERROR!" & vbCrLf & "The vehicle mileage cannot contain a non-number value")
            End If
        End If

        If txtprice.Text = "" Then
            MsgBox("Please enter vehicle price") ' this checks if the vehicle price is left blank, if it is  the text box becomes red.
            txtprice.BackColor = Color.Red
        ElseIf txtprice.Text <> "" Then
            If intcheck(txtprice.Text) Then ' if the price isn't blank the program checks if it is a integer, if it is not the the text box becomes red.
                txtprice.BackColor = Color.Green
                vehicle.price = txtprice.Text
            Else
                txtprice.BackColor = Color.Red
                MsgBox("ERROR!" & vbCrLf & "The vehicle price cannot contain a non-number value")
            End If
        End If

        If txtvehiclecolour.Text = "" Then ' this checks if the colour price is left blank, if it is  the text box becomes red.
            MsgBox("Please enter vehicle colour")
            txtvehiclecolour.BackColor = Color.Red
        Else
            vehicle.colour = txtvehiclecolour.Text
            txtvehiclecolour.BackColor = Color.Green
        End If

        If txtvehicleproblems.Text = "" Then
            MsgBox("Please enter vehicle problems")
            txtvehicleproblems.BackColor = Color.Red
        Else
            vehicle.problems = txtvehicleproblems.Text
            txtvehicleproblems.BackColor = Color.Green
        End If

        If txtnumofowners.Text = "" Then ' this checks if the number of owners is left blank, if it is  the text box becomes red.
            MsgBox("Please enter number of owners")
            txtnumofowners.BackColor = Color.Red
        ElseIf txtnumofowners.Text <> "" Then
            If intcheck(txtnumofowners.Text) Then ' if the number of owners isn't blank the program checks if it is a integer, if it is not the the text box becomes red.
                txtnumofowners.BackColor = Color.Green
                vehicle.owners = txtnumofowners.Text
            Else
                txtnumofowners.BackColor = Color.Red
                MsgBox("ERROR!" & vbCrLf & "The number of owners cannot contain a non-number value")
            End If
        End If

        If rbelectric.Checked = True Then ' this checks which radio button has been clicked to set the fuel type of the vehicle 
            vehicle.fueltype = rbelectric.Text
        ElseIf rbhybrid.Checked = True Then
            vehicle.fueltype = rbhybrid.Text
        ElseIf Rbpetrol.Checked = True Then
            vehicle.fueltype = Rbpetrol.Text
        ElseIf Rbdiesel.Checked = True Then
            vehicle.fueltype = Rbdiesel.Text
        End If
        If vehicle.fueltype = "" Then
            MsgBox("Please enter vehicle fuel type") ' if the user tries to save the details without a fuel type then this message is outputted.
        End If
        If Rbauto.Checked = True Then
            vehicle.transmission = Rbauto.Text
        Else
            vehicle.transmission = Rbmanual.Text
        End If
        If vehicle.transmission = "" Then
            MsgBox("Please enter vehicle transmission type") 'checks if the vehicle transmission is left blank
        End If
        If txtenginesize.Text = "" Then
            MsgBox("Please enter engine size")
            txtenginesize.BackColor = Color.Red

        Else
            txtenginesize.BackColor = Color.Green
            vehicle.enginesize = txtenginesize.Text
        End If

        'the system only saves the vehicle details if all the text boxes are green.
        If txtprice.BackColor = Color.Green And txtmileage.BackColor = Color.Green And txtregistrationnum.BackColor = Color.Green And txtnumofowners.BackColor = Color.Green And txtmodel.BackColor = Color.Green And txtmake.BackColor = Color.Green And txtprice.BackColor = Color.Green And txtvehicleproblems.BackColor = Color.Green And vehicle.transmission <> "" And vehicle.fueltype <> "" And txtenginesize.BackColor = Color.Green Then

            vehiclewriter.WriteLine(UCase(vehicle.regnumber) & "," & UCase(vehicle.make) & "," & UCase(vehicle.model) & "," & UCase(vehicle.colour) & "," & CInt(vehicle.mileage) & "," & Format(vehicle.price, "currency") & "," & UCase(vehicle.problems) & "," & CInt(vehicle.owners) & "," & UCase(vehicle.fueltype) & "," & UCase(vehicle.transmission) & "," & UCase(vehicle.enginesize))
            MsgBox("details saved")

        End If
        vehiclewriter.Close()
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click 'this allows the staff to access the staff portal and it clears all the text boxes.
        Me.Hide()
        Staffportal.Show()
        txtprice.Text = ""
        txtmileage.Text = ""

        txtregistrationnum.Text = ""
        txtnumofowners.Text = ""
        txtmodel.Text = ""
        txtmake.Text = ""
        txtvehicleproblems.Text = ""
        CBcusID.Text = ""
    End Sub


    Private Sub CBcusID_Enter(sender As Object, e As EventArgs) Handles CBcusID.Enter

        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True) 'reads from the customer details
        CBcusID.Items.Clear()
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",") ' splits the fields by , 
            CBcusID.Items.Add(customerrecords(0)) 'adds the customer ID's to combo box
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub

    Private Sub Rbpetrol_CheckedChanged(sender As Object, e As EventArgs) Handles Rbpetrol.CheckedChanged

    End Sub
End Class