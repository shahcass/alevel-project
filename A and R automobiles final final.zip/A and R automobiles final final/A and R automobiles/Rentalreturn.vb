﻿Imports System.IO
Public Class Rentalreturn

    Private Sub CBrentalID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBrentalID.SelectedIndexChanged
        'This event is triggered when the user selects a rental ID from the combo box.
        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)

        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing) '
            rentalrecords = stringline.Split("*") 'split comma delimted fields from rental detaisl into array
            If (rentalrecords(0) = CBrentalID.Text) Then 'Checks if the rental ID in the file matches the selected rental ID.
                txtcusID.Text = rentalrecords(1) 'If a match is found, the details of the rental are outputted to the designated text boxes.
                txtregnumber.Text = rentalrecords(2)
                txtdailyprice.Text = rentalrecords(3)
                DTPdatebooked.Text = rentalrecords(7)
                txtdaysrented.Text = rentalrecords(5)
                txttotal.Text = rentalrecords(6)
            End If
            stringline = rentalreader.ReadLine()
        End While
        rentalreader.Close()
    End Sub


    Private Sub CBrentalID_Enter(sender As Object, e As EventArgs) Handles CBrentalID.Enter
        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)
        CBrentalID.Items.Clear()
        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing) '
            rentalrecords = stringline.Split("*")
            CBrentalID.Items.Add(rentalrecords(0)) 'add first field to combo box
            stringline = rentalreader.ReadLine()
        End While
        rentalreader.Close()
    End Sub

    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click

        If Dir$("Temp.txt") = "" Then
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim rentalvehiclereader As New System.IO.StreamReader(Dir$("rentalvehicledetails.txt"), True)
        Dim sw As New System.IO.StreamWriter(Dir$("Temp.txt"), True)
        'these lines replace the old fields with the updated ones.
        stringline = rentalvehiclereader.ReadLine()
        While (stringline <> Nothing) 'The loop is executed until the end of the file is reached.
            rentalvehiclerecords = stringline.Split(",") 'split comma delimted fields into array
            If (rentalvehiclerecords(0) = txtregnumber.Text) Then 'if match found display record


                'when the text of the registration number changes the associated details of the vehicle are outputed to the text boxes
                rentalvehicles.regnumber = txtregnumber.Text
                rentalvehicles.make = txtmake.Text
                rentalvehicles.model = txtmodel.Text
                rentalvehicles.colour = txtvehiclecolour.Text
                rentalvehicles.transmission = rentalvehiclerecords(5)
                rentalvehicles.fueltype = rentalvehiclerecords(6)

                'Saves the to the rental vehicles file as the mileage driven by the customers has to be updated in the file.
                sw.WriteLine(rentalvehicles.regnumber & "," & rentalvehicles.make & "," & rentalvehicles.model & "," & rentalvehicles.colour & "," & Val(txtmileage.Text) + Val(txtmilesdriven.Text) & "," & rentalvehicles.fueltype & "," & rentalvehicles.transmission)
                stringline = rentalvehiclereader.ReadLine()
            Else
                sw.WriteLine(stringline)
                stringline = rentalvehiclereader.ReadLine()
            End If

        End While
        rentalvehiclereader.Close()
        sw.Close()

        File.Delete("rentalvehicledetails.txt")
        File.Move("Temp.txt", "rentalvehicledetails.txt")

    End Sub
    'these lines delete the rental records when the vehicle is returned 
    Private Sub savebtn_Click_1(sender As Object, e As EventArgs) Handles savebtn.Click
        If Dir$("Temp.txt") = "" Then 'check current project directory for movies.txt
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)
        Dim sw As New System.IO.StreamWriter(Dir$("Temp.txt"), True)

        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing)
            rentalrecords = stringline.Split("*") 'split comma delimted fields into array
            If (rentalrecords(0) <> CBrentalID.Text) Then 'if match found display record
                sw.WriteLine(stringline)
                stringline = rentalreader.ReadLine()
            Else
                stringline = rentalreader.ReadLine()
            End If

        End While
        rentalreader.Close()
        sw.Close()

        File.Delete("rentaldetails.txt") 'deletes rental details
        File.Move("Temp.txt", "rentaldetails.txt") 'this swaps the edited temp file and the rental details file.
        MsgBox("Vehicel returned!")



    End Sub


    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click 'allow staff to access the staff portal.
        Me.Hide()
        Staffportal.Show()
    End Sub

    Private Sub txtregnumber_TextChanged(sender As Object, e As EventArgs) Handles txtregnumber.TextChanged
        Dim rentalvehiclereader As New System.IO.StreamReader(Dir$("rentalvehicledetails.txt"), True)
        stringline = rentalvehiclereader.ReadLine()
        'outputs the associated fields to the assigned textboxes
        While (stringline <> Nothing)
            rentalvehiclerecords = stringline.Split(",") 'split comma delimted fields into array
            If (rentalvehiclerecords(0) = txtregnumber.Text) Then
                txtmake.Text = rentalvehiclerecords(1)
                txtmodel.Text = rentalvehiclerecords(2)
                txtvehiclecolour.Text = rentalvehiclerecords(3)
                txtmileage.Text = rentalvehiclerecords(4)

            End If
            stringline = rentalvehiclereader.ReadLine()
        End While
        rentalvehiclereader.Close()
    End Sub

    Private Sub Rentalreturn_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class