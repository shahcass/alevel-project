﻿Imports System.IO
Public Class Staffportal

    Private Sub customerdetailsbtn_Click(sender As Object, e As EventArgs) Handles customerdetailsbtn.Click 'allows staff to acces customer form
        Me.Hide()
        customerform.Show()
    End Sub

    Private Sub salebtn_Click(sender As Object, e As EventArgs) Handles salebtn.Click 'allows the staff to enter the vehicle sale form
        Me.Hide()
        vehiclesale.Show()
    End Sub

    Private Sub purchasebtn_Click(sender As Object, e As EventArgs) Handles purchasebtn.Click 'allows the staff to enter the vehicle purchase form
        Me.Hide()
        vehiclepurchase.Show()
    End Sub



    Private Sub vehicelrentalsbtn_Click(sender As Object, e As EventArgs) Handles vehicelrentalsbtn.Click 'allows the staff to enter the vehicle rental form
        Me.Hide()
        bookingorreturn.Show()

    End Sub

    Private Sub enterbtn_Click(sender As Object, e As EventArgs) Handles enterbtn.Click
        'this checks if the  satff Id and password are correct if it is staff are able to carry out tasks if not task page doesn't load
        Dim staffreader As New System.IO.StreamReader(Dir$("Staffdetails.txt"), True)
        stringline = staffreader.ReadLine()
        While (stringline <> Nothing) '
            staffrecords = stringline.Split(",") 'splits the staff records by "," and checks if the staff ID and password entered matches the database
            If (staffrecords(5) = txtstaffpass.Text) And (staffrecords(0) = txtstaffID.Text) Then
                staffgroupbox.Visible = True
                MsgBox("Access granted")
                sale.staffID = txtstaffID.Text
            End If
            stringline = staffreader.ReadLine()

        End While
        If staffgroupbox.Visible <> True Then
            MsgBox("Access denied,credentials entered are incorrect", vbExclamation)
            staffgroupbox.Visible = False
        End If
        staffreader.Close()
    End Sub

    Private Sub inventorybtn_Click(sender As Object, e As EventArgs) Handles inventorybtn.Click 'allows the staff to access the inventory report, that allows them to see all the vehicles that are currently in stock.
        Me.Hide()
        vehicleinventory.Show()
    End Sub

    Private Sub Rentalvehicelsbtn_Click(sender As Object, e As EventArgs) Handles Rentalvehicelsbtn.Click 'staff can add to the rental vehicles.
        Me.Hide()
        rentalvehicels.Show()
    End Sub

End Class