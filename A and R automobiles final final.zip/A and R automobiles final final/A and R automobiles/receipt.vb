﻿Imports System.IO

Public Class receipt
    Dim sales As ListViewItem

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click 'this button allows the staff to access the previous menu
        Me.Hide()
        managerportal.Show()
    End Sub
    'Reads the sale details and outputs the fields on to the list view for the manager to see the details of the vehicle sale.
    Private Sub receipt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim salereader As New System.IO.StreamReader(Dir$("Saledetails.txt"), True)
        lstsales.View = View.Details
        lstsales.GridLines = True
        lstsales.FullRowSelect = True
        lstsales.Scrollable = True
        lstsales.Columns.Add("Staff ID", 100)
        lstsales.Columns.Add("Customer ID", 100)
        lstsales.Columns.Add("Registration", 100)
        lstsales.Columns.Add("Price sold for", 100)
        lstsales.Columns.Add("Date sold", 100)
        lstsales.Columns.Add("Payment method", 100)
        lstsales.Columns.Add("Monthly or full payment", 100)
        lstsales.Columns.Add("Price bought for", 100)
        lstsales.Columns.Add("Profit made on sale", 140)


        stringline = salereader.ReadLine()
        While (stringline <> Nothing)
            salerecords = stringline.Split("*") 'split comma delimted fields into array
            line(0) = salerecords(0) ' all these lines are assigned to each sale detail.
            line(1) = salerecords(1)
            line(2) = salerecords(2)
            line(3) = salerecords(3)
            line(4) = salerecords(4)
            line(5) = salerecords(5)
            line(6) = salerecords(6)
            line(7) = salerecords(7)
            line(8) = salerecords(3) - salerecords(7) ' calculates the profit made by the 

            stringline = salereader.ReadLine() 'this adds all the vehicle details to the list view 
            sales = New ListViewItem(line)
            lstsales.Items.Add(sales)
        End While
        salereader.Close()
    End Sub

    Private Sub sortbtn_Click(sender As Object, e As EventArgs) Handles sortbtn.Click
        Dim Index As Integer
        Dim sales(0 To 20) As saledetails
        Dim Temp As saledetails
        Dim Swapped As Boolean
        Dim itm As New ListViewItem
        Index = 0
        lstsales.Clear()
        lstsales.View = View.Details
        lstsales.GridLines = True
        lstsales.FullRowSelect = True
        lstsales.Scrollable = True
        lstsales.Columns.Add("", 0)
        lstsales.Columns.Add("Staff ID", 100) 'Reads the sale details and outputs the fields on to the list view for the manager to see the details of the vehicle sale.
        lstsales.Columns.Add("Customer ID", 100)
        lstsales.Columns.Add("Registration", 100)
        lstsales.Columns.Add("Price sold for", 100)
        lstsales.Columns.Add("Date sold", 100)
        lstsales.Columns.Add("Payment method", 100)
        lstsales.Columns.Add("Monthly or full payment", 100)
        lstsales.Columns.Add("Price bought for", 100)
        lstsales.Columns.Add("Profit made on sale", 140)


        'populate array of records with unsorted sale details
        Dim salereader As New System.IO.StreamReader(Dir$("Saledetails.txt"), True)
        stringline = salereader.ReadLine()

        Do
            salerecords = stringline.Split("*")
            sales(Index).staffID = salerecords(0)
            sales(Index).customerID = salerecords(1)
            sales(Index).regnumber = salerecords(2)
            sales(Index).vehicleprice = salerecords(3)
            sales(Index).datebooked = salerecords(4)
            sales(Index).paymentmethod = salerecords(5)
            sales(Index).paymenttype = salerecords(6)
            sales(Index).priceboughtfor = salerecords(7)
            sales(Index).profitmade = salerecords(3) - salerecords(7)


            Index = Index + 1
            stringline = salereader.ReadLine()
        Loop While (stringline <> Nothing) '
        Index = Index - 1
        salereader.ReadLine()

        'perform bubble sort on profit by each sale in ascendning order.
        Do
            Swapped = False
            For I = 0 To (Index - 1)
                If (sales(I).profitmade > sales(I + 1).profitmade) Then 'If current profit is more than the next profitin the array perform a swap operation
                    'method 1
                    Temp = sales(I) 'put next item in temp
                    sales(I) = sales(I + 1) 'put current item in next item
                    sales(I + 1) = Temp 'put next item in current item 
                    Swapped = True 'set swap flag to true to test another cycle
                End If
            Next

        Loop Until (Swapped = False) 'This line drops out of loop when there is no swap

        'OUTPUT all records inorder your task

        For i = 0 To Index
            itm = New ListViewItem()
            itm.SubItems.AddRange({"" & sales(i).staffID, sales(i).customerID, sales(i).regnumber, sales(i).vehicleprice, sales(i).datebooked, sales(i).paymentmethod, sales(i).paymenttype, sales(i).priceboughtfor, sales(i).profitmade}) 'outputs the sale details in order of profit made.
            lstsales.Items.Add(itm)
        Next i
    End Sub

End Class