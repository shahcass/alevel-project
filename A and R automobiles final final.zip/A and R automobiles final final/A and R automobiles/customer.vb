﻿Imports System.IO
Public Class customerform
    Dim customernum As Integer = 1
    Public index As Integer = 0
    Dim numgenerator As New Random()


    Private Sub customerform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' this creates a new customerdetails file if the file is empty
        If Dir$("Customerdetails.txt") = "" Then
            Dim sw As New StreamWriter(Application.StartupPath & "\Customerdetails.txt", True)
        End If
        DTPDOB.MaxDate = DTPDOB.Value.AddDays(-6209) 'this sets the max date so that the customer has to be atleast 17 years of age to purchase a vehicle or rent a vehicle
    End Sub
    Private Sub CBcustomerID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBcustomerID.SelectedIndexChanged
        ' This event is raised when a user selects an item from a combo box.
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True) 'when the combo box is clicked it will show all the customers details in the assigned text boxes
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",") 'split comma delimted fields into array
            If (customerrecords(0) = CBcustomerID.Text) Then
                CBfname.Text = customerrecords(1)
                txtCsurname.Text = customerrecords(2)
                txtCphonenum.Text = customerrecords(3)
                txtaddress.Text = customerrecords(4)
                txtpostcode.Text = customerrecords(5)
                DTPDOB.Text = customerrecords(6)
            End If
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub

    Private Sub submitbtn_Click(sender As Object, e As EventArgs) Handles submitbtn.Click
        Dim customerwriter As New System.IO.StreamWriter(Dir$("Customerdetails.txt"), True)

        ' applies checks to each field , if a check is failed it will not save to the file until the check has been passed

        If Len(txtCphonenum.Text) = 11 Then
            txtCphonenum.BackColor = Color.Green
            customers(3, index) = txtCphonenum.Text
        ElseIf Len(txtCphonenum.Text) <> 11 Then
            txtCphonenum.BackColor = Color.Red
            MsgBox("Please enter a valid  phone number") ' length check on the phone number as the phone number has to be 11 digits long
        End If

        If CBfname.Text = "" Then 'checks if all the characters in the first name field are letters
            CBfname.BackColor = Color.Red
            MsgBox("Please enter a firstname")
        ElseIf CBfname.Text <> "" Then
            For i = 0 To Len(CBfname.Text) - 1
                If (Asc(CBfname.Text(i)) < 65 Or Asc(CBfname.Text(i)) > 122) Or (Asc(CBfname.Text(i)) > 91 And Asc(CBfname.Text(i)) < 96) Then
                    MsgBox("ERROR!" & vbCrLf & "There is a non-letter value in the first name field")
                    CBfname.BackColor = Color.Red
                Else
                    CBfname.BackColor = Color.Green
                    customers(1, index) = CBfname.Text
                End If
            Next i

        End If
        If txtCsurname.Text = "" Then 'checks if all the characters in the surname field are letters
            txtCsurname.BackColor = Color.Red
            MsgBox("Please enter a surname")
        ElseIf txtCsurname.Text <> "" Then
            For i = 0 To Len(txtCsurname.Text) - 1
                If (Asc(txtCsurname.Text(i)) < 65 Or Asc(txtCsurname.Text(i)) > 122) Or (Asc(txtCsurname.Text(i)) > 91 And Asc(txtCsurname.Text(i)) < 96) Then
                    MsgBox("ERROR!" & vbCrLf & "There is a non-letter value in the surname field")
                    txtCsurname.BackColor = Color.Red
                Else
                    txtCsurname.BackColor = Color.Green
                    customers(2, index) = txtCsurname.Text

                End If
            Next i

        End If

        If DTPDOB.Text = "" Then

            MsgBox("Please enter a date of birth name")
        Else
            customers(6, index) = DTPDOB.Text
        End If
        If txtpostcode.Text = "" Then
            txtpostcode.BackColor = Color.Red
            MsgBox("please enter a postcode")
        Else
            txtpostcode.BackColor = Color.Green 'presence check on the address
            customers(4, index) = txtpostcode.Text
        End If

        If txtaddress.Text = "" Then
            txtaddress.BackColor = Color.Red
            MsgBox("please enter a address")
        Else
            txtaddress.BackColor = Color.Green 'presence check on the address
            customers(5, index) = txtaddress.Text
        End If



        customernum = numgenerator.Next(1, 101) 'this generates a random customer number to enusre that each customer ID is unique from another.



        If txtpostcode.BackColor = Color.Green And CBfname.BackColor = Color.Green And DTPDOB.Text <> "" And Len(txtCphonenum.Text) = 11 And txtCsurname.BackColor = Color.Green Then  ' saves all the customer details to the file only if the checks have been passed
            customers(0, index) = Mid(customers(1, index), 1, 1) & Mid(customers(2, index), 1, 4) & customernum ' generates a customer ID for the customer using their fistname, surname and a random  number 
            customerwriter.WriteLine(customers(0, index) & "," & customers(1, index) & "," & customers(2, index) & "," & customers(3, index) & "," & customers(4, index) & "," & customers(5, index) & "," & customers(6, index))
            index = index + 1
            MsgBox("details saved")
        End If

        customerwriter.Close()
    End Sub

    Private Sub editbtn_Click(sender As Object, e As EventArgs) Handles editbtn.Click
        Dim index As Integer
        If Dir$("Temp.txt") = "" Then 'check current project directory for movies.txt
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True)
        Dim tempwriter As New System.IO.StreamWriter(Dir$("Temp.txt"), True)
        ' these lines replace the old fields with the updated fields
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing)
            customerrecords = stringline.Split(",") 'split comma delimted fields into array
            If (customerrecords(0) = CBcustomerID.Text) Then 'if match found display record

                'these lines save the edited details of the custoemr and correctly allocates the to the reight records.

                customers(3, index) = txtCphonenum.Text
                customers(1, index) = CBfname.Text
                customers(2, index) = txtCsurname.Text
                customers(6, index) = DTPDOB.Text
                customers(4, index) = txtpostcode.Text
                customers(5, index) = txtaddress.Text
                customernum = numgenerator.Next(1, 101) 'this generates a random customer number to enusre that each customer ID is unique from another.
            End If

            customers(0, index) = Mid(customers(1, index), 1, 1) & Mid(customers(2, index), 1, 4) & customernum
                    tempwriter.WriteLine(customers(0, index) + "," & customers(1, index) + "," & customers(2, index) + "," & customers(3, index) + "," & customers(4, index) + "," + customers(5, index) + "," + customers(6, index)) ' saves to the file
                    stringline = customerreader.ReadLine()

            tempwriter.WriteLine(stringline)
                    stringline = customerreader.ReadLine()



        End While
        customerreader.Close()
        tempwriter.Close()

        File.Delete("Customerdetails.txt") 'delete customer file
        File.Move("Temp.txt", "Customerdetails.txt") 're-create new customer file with edited record
        MsgBox("details edited!")
    End Sub

    Private Sub CBcustomerID_Enter(sender As Object, e As EventArgs) Handles CBcustomerID.Enter
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True) 'reads from the customer details
        CBcustomerID.Items.Clear()
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",") ' splits the fields by , 
            CBcustomerID.Items.Add(customerrecords(0)) 'adds the customer ID's to combo box
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub

    Private Sub deletebtn_Click(sender As Object, e As EventArgs) Handles deletebtn.Click
        If Dir$("Temp.txt") = "" Then 'check current project directory for customerstxt
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim sr As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True)
        Dim sw As New System.IO.StreamWriter(Dir$("Temp.txt"), True)

        stringline = sr.ReadLine()
        While (stringline <> Nothing)
            customerrecords = stringline.Split(",") 'splits customer fields by commas
            If (customerrecords(0) <> CBcustomerID.Text) Then 'if the customer ID is found it is displayed to be deleted
                sw.WriteLine(stringline)
                stringline = sr.ReadLine()
            Else
                stringline = sr.ReadLine()
            End If

        End While
        sr.Close()
        sw.Close()
        index = index - 1
        File.Delete("Customerdetails.txt") 'deletes customer file
        File.Move("Temp.txt", "Customerdetails.txt") 're-create new customer file with edited record
        MsgBox("details deleted!") ' a confirmation message on deleting
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click ' this clears all the textboxes when the staff visits the previous menu
        Me.Hide()
        Staffportal.Show()
        CBfname.Text = ""
        txtCsurname.Text = ""
        txtpostcode.Text = ""
        txtCphonenum.Text = ""
        txtpostcode.Text = ""
        CBcustomerID.Text = ""
        txtaddress.Text = ""
    End Sub

    Private Sub help2_MouseHover(sender As Object, e As EventArgs) Handles help2.MouseHover
        ToolTiphelp.Show("The phone number has to contain 11 digits", help2)
    End Sub

    Private Sub help4_MouseHover(sender As Object, e As EventArgs) Handles help4.MouseHover
        ToolTiphelp.Show("The surname can only contain letters", help4)
    End Sub

    Private Sub help5_MouseHover(sender As Object, e As EventArgs) Handles help5.MouseHover
        ToolTiphelp.Show("The first name can only contain letters", help5)
    End Sub

    Private Sub CBfname_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBfname.SelectedIndexChanged
        ' This event is raised when a user selects an item from a combo box.
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True) 'when the combo box is clicked it will show all the customers details in the assigned text boxes
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",") 'split comma delimted fields into array
            If (CBfname.Text = customerrecords(1)) Then
                CBcustomerID.Text = customerrecords(0)
                txtCsurname.Text = customerrecords(2)
                txtCphonenum.Text = customerrecords(3)
                txtaddress.Text = customerrecords(4)
                txtpostcode.Text = customerrecords(5)
                DTPDOB.Text = customerrecords(6)
            End If
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub

    Private Sub CBfname_Enter(sender As Object, e As EventArgs) Handles CBfname.Enter
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True) 'reads from the customer details
        CBfname.Items.Clear()
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",") ' splits the fields by , 
            CBfname.Items.Add(customerrecords(1)) 'adds the customer ID's to combo box
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub
End Class