﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class vehiclepurchase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtregistrationnum = New System.Windows.Forms.TextBox()
        Me.txtmileage = New System.Windows.Forms.TextBox()
        Me.txtprice = New System.Windows.Forms.TextBox()
        Me.txtnumofowners = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.savebtn = New System.Windows.Forms.Button()
        Me.txtmake = New System.Windows.Forms.TextBox()
        Me.txtmodel = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtvehiclecolour = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtvehicleproblems = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.backbtn = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Rbauto = New System.Windows.Forms.RadioButton()
        Me.Rbmanual = New System.Windows.Forms.RadioButton()
        Me.CBcusID = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbhybrid = New System.Windows.Forms.RadioButton()
        Me.rbelectric = New System.Windows.Forms.RadioButton()
        Me.Rbpetrol = New System.Windows.Forms.RadioButton()
        Me.Rbdiesel = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtenginesize = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(100, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(238, 62)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Vehicle purchase" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "form"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 103)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 26)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Registration " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "number"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 139)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Make"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 167)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Model"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 194)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Mileage"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 447)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Price"
        '
        'txtregistrationnum
        '
        Me.txtregistrationnum.Location = New System.Drawing.Point(82, 109)
        Me.txtregistrationnum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtregistrationnum.Name = "txtregistrationnum"
        Me.txtregistrationnum.Size = New System.Drawing.Size(76, 20)
        Me.txtregistrationnum.TabIndex = 6
        '
        'txtmileage
        '
        Me.txtmileage.Location = New System.Drawing.Point(82, 187)
        Me.txtmileage.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtmileage.Name = "txtmileage"
        Me.txtmileage.Size = New System.Drawing.Size(76, 20)
        Me.txtmileage.TabIndex = 9
        '
        'txtprice
        '
        Me.txtprice.Location = New System.Drawing.Point(80, 443)
        Me.txtprice.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtprice.Name = "txtprice"
        Me.txtprice.Size = New System.Drawing.Size(76, 20)
        Me.txtprice.TabIndex = 10
        '
        'txtnumofowners
        '
        Me.txtnumofowners.Location = New System.Drawing.Point(98, 395)
        Me.txtnumofowners.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtnumofowners.Name = "txtnumofowners"
        Me.txtnumofowners.Size = New System.Drawing.Size(56, 20)
        Me.txtnumofowners.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(9, 388)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 26)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Number of " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "previous owners"
        '
        'savebtn
        '
        Me.savebtn.BackColor = System.Drawing.SystemColors.Highlight
        Me.savebtn.Location = New System.Drawing.Point(12, 500)
        Me.savebtn.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.savebtn.Name = "savebtn"
        Me.savebtn.Size = New System.Drawing.Size(103, 59)
        Me.savebtn.TabIndex = 16
        Me.savebtn.Text = "save vehicle details"
        Me.savebtn.UseVisualStyleBackColor = False
        '
        'txtmake
        '
        Me.txtmake.Location = New System.Drawing.Point(82, 139)
        Me.txtmake.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtmake.Name = "txtmake"
        Me.txtmake.Size = New System.Drawing.Size(76, 20)
        Me.txtmake.TabIndex = 17
        '
        'txtmodel
        '
        Me.txtmodel.Location = New System.Drawing.Point(82, 164)
        Me.txtmodel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtmodel.Name = "txtmodel"
        Me.txtmodel.Size = New System.Drawing.Size(76, 20)
        Me.txtmodel.TabIndex = 18
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 365)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "colour"
        '
        'txtvehiclecolour
        '
        Me.txtvehiclecolour.Location = New System.Drawing.Point(80, 365)
        Me.txtvehiclecolour.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtvehiclecolour.Name = "txtvehiclecolour"
        Me.txtvehiclecolour.Size = New System.Drawing.Size(76, 20)
        Me.txtvehiclecolour.TabIndex = 20
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.A_and_R_automobiles.My.Resources.Resources.Untitled1
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(106, 66)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 41
        Me.PictureBox1.TabStop = False
        '
        'txtvehicleproblems
        '
        Me.txtvehicleproblems.Location = New System.Drawing.Point(80, 418)
        Me.txtvehicleproblems.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtvehicleproblems.Name = "txtvehicleproblems"
        Me.txtvehicleproblems.Size = New System.Drawing.Size(76, 20)
        Me.txtvehicleproblems.TabIndex = 42
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 418)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 26)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "existing" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "problems"
        '
        'backbtn
        '
        Me.backbtn.BackColor = System.Drawing.SystemColors.Highlight
        Me.backbtn.Location = New System.Drawing.Point(146, 500)
        Me.backbtn.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.backbtn.Name = "backbtn"
        Me.backbtn.Size = New System.Drawing.Size(103, 59)
        Me.backbtn.TabIndex = 44
        Me.backbtn.Text = "Previous menu"
        Me.backbtn.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Rbauto)
        Me.GroupBox1.Controls.Add(Me.Rbmanual)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 300)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(85, 60)
        Me.GroupBox1.TabIndex = 48
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "transmission"
        '
        'Rbauto
        '
        Me.Rbauto.AutoSize = True
        Me.Rbauto.Location = New System.Drawing.Point(6, 19)
        Me.Rbauto.Name = "Rbauto"
        Me.Rbauto.Size = New System.Drawing.Size(71, 17)
        Me.Rbauto.TabIndex = 49
        Me.Rbauto.TabStop = True
        Me.Rbauto.Text = "automatic"
        Me.Rbauto.UseVisualStyleBackColor = True
        '
        'Rbmanual
        '
        Me.Rbmanual.AutoSize = True
        Me.Rbmanual.Location = New System.Drawing.Point(6, 40)
        Me.Rbmanual.Name = "Rbmanual"
        Me.Rbmanual.Size = New System.Drawing.Size(59, 17)
        Me.Rbmanual.TabIndex = 50
        Me.Rbmanual.TabStop = True
        Me.Rbmanual.Text = "manual"
        Me.Rbmanual.UseVisualStyleBackColor = True
        '
        'CBcusID
        '
        Me.CBcusID.FormattingEnabled = True
        Me.CBcusID.Location = New System.Drawing.Point(82, 83)
        Me.CBcusID.Name = "CBcusID"
        Me.CBcusID.Size = New System.Drawing.Size(89, 21)
        Me.CBcusID.TabIndex = 49
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 86)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 13)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "Customer ID"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbhybrid)
        Me.GroupBox2.Controls.Add(Me.rbelectric)
        Me.GroupBox2.Controls.Add(Me.Rbpetrol)
        Me.GroupBox2.Controls.Add(Me.Rbdiesel)
        Me.GroupBox2.Location = New System.Drawing.Point(18, 221)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(126, 72)
        Me.GroupBox2.TabIndex = 51
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "fuel type"
        '
        'rbhybrid
        '
        Me.rbhybrid.AutoSize = True
        Me.rbhybrid.Location = New System.Drawing.Point(62, 42)
        Me.rbhybrid.Name = "rbhybrid"
        Me.rbhybrid.Size = New System.Drawing.Size(55, 17)
        Me.rbhybrid.TabIndex = 52
        Me.rbhybrid.TabStop = True
        Me.rbhybrid.Text = "Hybrid"
        Me.rbhybrid.UseVisualStyleBackColor = True
        '
        'rbelectric
        '
        Me.rbelectric.AutoSize = True
        Me.rbelectric.Location = New System.Drawing.Point(62, 19)
        Me.rbelectric.Name = "rbelectric"
        Me.rbelectric.Size = New System.Drawing.Size(60, 17)
        Me.rbelectric.TabIndex = 51
        Me.rbelectric.TabStop = True
        Me.rbelectric.Text = "Electric"
        Me.rbelectric.UseVisualStyleBackColor = True
        '
        'Rbpetrol
        '
        Me.Rbpetrol.AutoSize = True
        Me.Rbpetrol.Location = New System.Drawing.Point(6, 19)
        Me.Rbpetrol.Name = "Rbpetrol"
        Me.Rbpetrol.Size = New System.Drawing.Size(52, 17)
        Me.Rbpetrol.TabIndex = 49
        Me.Rbpetrol.TabStop = True
        Me.Rbpetrol.Text = "Petrol"
        Me.Rbpetrol.UseVisualStyleBackColor = True
        '
        'Rbdiesel
        '
        Me.Rbdiesel.AutoSize = True
        Me.Rbdiesel.Location = New System.Drawing.Point(6, 40)
        Me.Rbdiesel.Name = "Rbdiesel"
        Me.Rbdiesel.Size = New System.Drawing.Size(54, 17)
        Me.Rbdiesel.TabIndex = 50
        Me.Rbdiesel.TabStop = True
        Me.Rbdiesel.Text = "Diesel"
        Me.Rbdiesel.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 468)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 13)
        Me.Label10.TabIndex = 52
        Me.Label10.Text = "Engine size(L)"
        '
        'txtenginesize
        '
        Me.txtenginesize.Location = New System.Drawing.Point(118, 464)
        Me.txtenginesize.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtenginesize.Name = "txtenginesize"
        Me.txtenginesize.Size = New System.Drawing.Size(37, 20)
        Me.txtenginesize.TabIndex = 53
        '
        'vehiclepurchase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(336, 568)
        Me.Controls.Add(Me.txtenginesize)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.CBcusID)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.backbtn)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtvehicleproblems)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtvehiclecolour)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtmodel)
        Me.Controls.Add(Me.txtmake)
        Me.Controls.Add(Me.savebtn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtnumofowners)
        Me.Controls.Add(Me.txtprice)
        Me.Controls.Add(Me.txtmileage)
        Me.Controls.Add(Me.txtregistrationnum)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "vehiclepurchase"
        Me.Text = "vehicleform"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtregistrationnum As TextBox
    Friend WithEvents txtmileage As TextBox
    Friend WithEvents txtprice As TextBox
    Friend WithEvents txtnumofowners As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents savebtn As Button
    Friend WithEvents txtmake As TextBox
    Friend WithEvents txtmodel As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtvehiclecolour As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtvehicleproblems As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents backbtn As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Rbmanual As RadioButton
    Friend WithEvents Rbauto As RadioButton
    Friend WithEvents CBcusID As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbhybrid As RadioButton
    Friend WithEvents rbelectric As RadioButton
    Friend WithEvents Rbpetrol As RadioButton
    Friend WithEvents Rbdiesel As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents txtenginesize As TextBox
End Class
