﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class receipt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.backbtn = New System.Windows.Forms.Button()
        Me.lstsales = New System.Windows.Forms.ListView()
        Me.sortbtn = New System.Windows.Forms.Button()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(167, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 52)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "Sales"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.A_and_R_automobiles.My.Resources.Resources.Untitled1
        Me.PictureBox2.Location = New System.Drawing.Point(-9, -2)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(168, 94)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 124
        Me.PictureBox2.TabStop = False
        '
        'backbtn
        '
        Me.backbtn.BackColor = System.Drawing.SystemColors.Highlight
        Me.backbtn.Location = New System.Drawing.Point(324, 499)
        Me.backbtn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.backbtn.Name = "backbtn"
        Me.backbtn.Size = New System.Drawing.Size(123, 65)
        Me.backbtn.TabIndex = 125
        Me.backbtn.Text = "Return to manager portal"
        Me.backbtn.UseVisualStyleBackColor = False
        '
        'lstsales
        '
        Me.lstsales.GridLines = True
        Me.lstsales.HideSelection = False
        Me.lstsales.Location = New System.Drawing.Point(3, 180)
        Me.lstsales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.lstsales.Name = "lstsales"
        Me.lstsales.Size = New System.Drawing.Size(776, 313)
        Me.lstsales.TabIndex = 126
        Me.lstsales.UseCompatibleStateImageBehavior = False
        '
        'sortbtn
        '
        Me.sortbtn.BackColor = System.Drawing.Color.IndianRed
        Me.sortbtn.Location = New System.Drawing.Point(294, 89)
        Me.sortbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.sortbtn.Name = "sortbtn"
        Me.sortbtn.Size = New System.Drawing.Size(153, 70)
        Me.sortbtn.TabIndex = 127
        Me.sortbtn.Text = "Sort profits in ascending order"
        Me.sortbtn.UseVisualStyleBackColor = False
        '
        'receipt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(780, 587)
        Me.Controls.Add(Me.sortbtn)
        Me.Controls.Add(Me.lstsales)
        Me.Controls.Add(Me.backbtn)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "receipt"
        Me.Text = "S"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents backbtn As Button
    Friend WithEvents lstsales As ListView
    Friend WithEvents sortbtn As Button
End Class
