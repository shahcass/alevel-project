﻿Imports System.IO
Public Class rentalform


    Private Sub rentalform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim rental As New A_and_R_automobiles.rentaldetails
        If Dir$("rentaldetails.txt") = "" Then
            Dim sw As New StreamWriter(Application.StartupPath & "\rentaldetails.txt", True)
        End If
        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)


        lstrental.View = View.Details 'i have declared the properties of the listview here 
        lstrental.GridLines = True
        lstrental.FullRowSelect = True
        lstrental.Scrollable = True

        lstrental.Columns.Add("Registrtion number", 100) 'all the headings of the lsitview are declared here
        lstrental.Columns.Add("Date booked", 100)
        lstrental.Columns.Add("Days rented for", 100)
        lstrental.Columns.Add("Date being returned", 200)

        stringline = rentalreader.ReadLine()
        'this shows the staff what vehicles are out for rent,to prevent double booking.
        While (stringline <> Nothing) '
            rentalrecords = stringline.Split("*") 'splits the rental records by comma
            line(0) = rentalrecords(2) ' all these lines are assigned to each rental detail.
            line(1) = rentalrecords(4)
            line(2) = rentalrecords(5)
            line(3) = rentalrecords(7)



            stringline = rentalreader.ReadLine() 'this adds all the rental details to the list view 
            stock = New ListViewItem(line)
            lstrental.Items.Add(stock)
        End While
        rentalreader.Close()

        DTPdatebooked.MinDate = Today 'this sets the minimum date on the date time picker as today , as you cannot book a vehicle before today.
        DTPdatebooked.MaxDate = DTPdatebooked.Value.AddDays(14) ' this makes the date time picker only show dates that are 2 weeks from now.

    End Sub

    Private Sub CBregnumber_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBregnumber.SelectedIndexChanged
        ' The is a ComboBox control named "CBregnumber" that allows the staff to choose which vehicle is being rented. When the staff selects a registration number from the ComboBox,
        ' the code reads the "rentalvehicledetails.txt" file  and looks for the line that has the same registration number as the one selected in the ComboBox. Once the line is found,
        ' the code displays the vehicle make, model, colour, and mileage associated with that registration number in separate TextBox controls.
        Dim rentalvehiclereader As New System.IO.StreamReader(Dir$("rentalvehicledetails.txt"), True)
        stringline = rentalvehiclereader.ReadLine()
        While (stringline <> Nothing) '
            rentalvehiclerecords = stringline.Split(",") 'split comma delimted fields into array
            If (rentalvehiclerecords(0) = CBregnumber.Text) Then ' this line checks which registration number is chosen and the details associated are presented
                txtmake.Text = rentalvehiclerecords(1)
                txtmodel.Text = rentalvehiclerecords(2)
                txtvehiclecolour.Text = rentalvehiclerecords(3)
                txtmileage.Text = rentalvehiclerecords(4)

            End If
            stringline = rentalvehiclereader.ReadLine()
        End While
        rentalvehiclereader.Close()
    End Sub


    Private Sub CBregnumber_Enter(sender As Object, e As EventArgs) Handles CBregnumber.Enter ' the combo box allows staff to choose which vehicle is being rented
        Dim rentalvehiclereader As New System.IO.StreamReader(Dir$("rentalvehicledetails.txt"), True)
        CBregnumber.Items.Clear()
        stringline = rentalvehiclereader.ReadLine()
        While (stringline <> Nothing) '
            rentalvehiclerecords = stringline.Split(",")

            CBregnumber.Items.Add(rentalvehiclerecords(0))
            stringline = rentalvehiclereader.ReadLine()

        End While
        rentalvehiclereader.Close()
    End Sub

    Private Sub CBcustomerID_Enter(sender As Object, e As EventArgs) Handles CBcustomerID.Enter ' this outputs all the customer ID's, the staff member choses which customer is renting the vehicle
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True)
        CBcustomerID.Items.Clear()
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",")
            CBcustomerID.Items.Add(customerrecords(0)) 'add first field to combo box
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub
    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click

        'this code checks if the  fields are empty and applies validation checks to them. If either fields are empty or if fields fail a check, the code displays an error message. If fields pass the checks, the code saves
        'the rental record to the "rentaldetails.txt" file. Before saving the record, the code checks if the selected registration number matches a registration number in the "rentaldetails.txt" file.
        'If there is a match, the code displays an error message and does not save the record, this is done so that the vehicle cant be booked when its gone out for rental.
        Using rentalwriter As New StreamWriter(Dir$("rentaldetails.txt"), True)


            If CBcustomerID.Text = "" Then 'this is a presence check on the customer ID as it cannot be left blank
                MsgBox("Please enter customer ID")
                CBcustomerID.BackColor = Color.Red
            Else
                rental.customerID = CBcustomerID.Text
                CBcustomerID.BackColor = Color.Green
            End If

            If CBregnumber.Text = "" Then 'this is a presence check on the registration number as it cannot be left blank
                MsgBox("Please enter registration number")
            ElseIf CBregnumber.Text = rentalrecords(2) Then 'this checks the rental records and the registation number of the vehicle wanting to be rented,if they match the vehicle cannot be rented, as a vehicle that has been gone out for rent cannot be booked.
                CBregnumber.Text = rentalrecords(2)
                MsgBox("Vehicle is out for rent, please choose another vehicle")
                CBregnumber.BackColor = Color.Red

            Else
                CBregnumber.BackColor = Color.Green
                rental.regnumber = CBregnumber.Text
            End If

            If txtdailyprice.Text = "" Then 'this checks if the daily price isnt blank and checks if it is a integer.
                MsgBox("Please enter daily price of vehicle")
                txtdailyprice.BackColor = Color.Red
            ElseIf txtdailyprice.Text <> "" Then
                If intcheck(txtdailyprice.Text) Then
                    txtdailyprice.BackColor = Color.Green
                    rental.dailyprice = Format(txtdailyprice.Text, "currency")
                Else
                    txtdailyprice.BackColor = Color.Red
                    MsgBox("ERROR!" & vbCrLf & "The daily price cannot contain a non-number value")
                End If
            End If


            If txtdaysrented.Text = "" Then 'a presence check is applied to the days rented and checks if it is a integer.
                MsgBox("Please enter daily price of vehicle")
                txtdaysrented.BackColor = Color.Red
            ElseIf txtdaysrented.Text <> "" Then
                If intcheck(txtdaysrented.Text) Then
                    txtdaysrented.BackColor = Color.Green
                    rental.daysrented = txtdaysrented.Text
                Else
                    txtdaysrented.BackColor = Color.Red
                    MsgBox("ERROR!" & vbCrLf & "The days rented cannot contain a non-number value")
                End If
            End If
            rental.datebooked = DTPdatebooked.Text
            If txtdaysrented.Text = "" And txtdailyprice.Text = "" Then
                txttotal.BackColor = Color.Red
            Else
                txttotal.Text = Format(txtdaysrented.Text * txtdailyprice.Text, "currency") 'this calculates the total price of the rental.
                rental.total = txtdaysrented.Text * txtdailyprice.Text
            End If

            rental.returndate = Mid(DTPdatebooked.Value.AddDays(txtdaysrented.Text), 1, 8) 'this line finds the rental return date with just the booking date and daysrented.
            rental.rentalID = Mid(CBcustomerID.Text, 1, 4) & Mid(DTPdatebooked.Text, 1, 3)

            If CBregnumber.BackColor = Color.Green And CBcustomerID.BackColor = Color.Green And txtdaysrented.BackColor = Color.Green And txtdailyprice.BackColor = Color.Green Then
                rentalwriter.WriteLine(rental.rentalID & "*" & rental.customerID & "*" & rental.regnumber & "*" & rental.dailyprice & "*" & rental.datebooked & "*" & rental.daysrented & "*" & Format(rental.total, "currency") & "*" & rental.returndate) ' saves all the rental details to the file
                MsgBox("order saved")


                rentalwriter.Close()
            End If


        End Using

    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click
        'this clears all the text boxes and allows staff to access the previous menu
        Me.Hide()
        Staffportal.Show()
        CBcustomerID.Text = ""
        CBregnumber.Text = ""
        txtdailyprice.Text = ""
        txttotal.Text = ""
        txtdailyprice.Text = ""
        txtdaysrented.Text = ""
        txtmake.Text = ""
        txtmodel.Text = ""
        txtvehiclecolour.Text = ""
        txtmileage.Text = ""
        CBrentalID.Text = ""

    End Sub

    Private Sub CBrentalID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBrentalID.SelectedIndexChanged
        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)
        'this outputs the rental details to the associated text boxes
        DTPdatebooked.MinDate = rentalrecords(4)
        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing) '
            rentalrecords = stringline.Split("*") 'split comma delimted fields into array
            If (rentalrecords(0) = CBrentalID.Text) Then
                CBcustomerID.Text = rentalrecords(1)
                CBregnumber.Text = rentalrecords(2)
                txtdailyprice.Text = rentalrecords(3)
                DTPdatebooked.Text = rentalrecords(4)
                txtdaysrented.Text = rentalrecords(5)
                txttotal.Text = rentalrecords(6)
            End If
            stringline = rentalreader.ReadLine()
        End While
        rentalreader.Close()
    End Sub


    Private Sub CBrentalID_Enter(sender As Object, e As EventArgs) Handles CBrentalID.Enter
        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)
        CBrentalID.Items.Clear()
        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing) '
            rentalrecords = stringline.Split("*") 'splits the rental records by comma
            CBrentalID.Items.Add(rentalrecords(0)) 'adds the first field to combo box
            stringline = rentalreader.ReadLine()
        End While
        rentalreader.Close()
    End Sub


    Private Sub CBregnumber_TextChanged(sender As Object, e As EventArgs) Handles CBregnumber.TextChanged
        Dim rentalvehiclereader As New System.IO.StreamReader(Dir$("rentalvehicledetails.txt"), True)
        stringline = rentalvehiclereader.ReadLine()
        'when a registration number of a rental vehicle is shown in the text box all the assigned details will be presented.
        While (stringline <> Nothing) '
            rentalvehiclerecords = stringline.Split(",") 'splits comma delimted fields into array
            If (rentalvehiclerecords(0) = CBregnumber.Text) Then
                txtmake.Text = rentalvehiclerecords(1)
                txtmodel.Text = rentalvehiclerecords(2)
                txtvehiclecolour.Text = rentalvehiclerecords(3)
                txtmileage.Text = rentalvehiclerecords(4)

            End If
            stringline = rentalvehiclereader.ReadLine()
        End While
        rentalvehiclereader.Close()
    End Sub

    Private Sub deletebtn_Click(sender As Object, e As EventArgs) Handles deletebtn.Click
        If Dir$("Temp.txt") = "" Then 'check current project directory for movies.txt
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim rentalreader As New System.IO.StreamReader(Dir$("rentaldetails.txt"), True)
        Dim sw As New System.IO.StreamWriter(Dir$("Temp.txt"), True)

        stringline = rentalreader.ReadLine()
        While (stringline <> Nothing)
            staffrecords = stringline.Split(",") 'split comma delimted fields into array
            If (rentalrecords(0) <> CBrentalID.Text) Then 'if match found display record
                sw.WriteLine(stringline)
                stringline = rentalreader.ReadLine()
            Else
                stringline = rentalreader.ReadLine()
            End If

        End While
        rentalreader.Close()
        sw.Close()

        File.Delete("rentaldetails.txt") 'delete Staff file
        File.Move("Temp.txt", "rentaldetails.txt") 're-create new Staff file with edited record
        MsgBox("details deleted!")
    End Sub


End Class