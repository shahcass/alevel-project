﻿Imports System.IO
Public Class vehiclesale
    ' vehcile sale form where all the details about the vehicle sale is stored and 
    Private Sub vehiclesale_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sale As New A_and_R_automobiles.saledetails
        If Dir$("Saledetails.txt") = "" Then
            Dim sw As New StreamWriter(Application.StartupPath & "\Saledetails.txt", True)
        End If
        DTPbookeddate.MinDate = Today 'this sets the minimum date on the date time picker as today , as you cannot book a vehicle before today.
        DTPbookeddate.MaxDate = DTPbookeddate.Value.AddDays(14) ' this makes the date time picker only show dates that are 2 weeks from now.
    End Sub

    'if a registration number is clicked it would output all the vehicle details to the assigned text boxes.
    Private Sub CBregistrationnum_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBregistrationnum.SelectedIndexChanged
        Dim vehiiclereader As New System.IO.StreamReader(Dir$("vehicledetails.txt"), True)
        stringline = vehiiclereader.ReadLine()
        While (stringline <> Nothing) '
            vehiclerecords = stringline.Split(",")
            'If a match is found, the details of the rental are outputted to the designated text boxes.
            If (vehiclerecords(0) = CBregistrationnum.Text) Then ' 
                txtmake.Text = vehiclerecords(1)
                txtmodel.Text = vehiclerecords(2)
                txtcolour.Text = vehiclerecords(3)
                txtmileage.Text = vehiclerecords(4)
                txtvehicleproblems.Text = vehiclerecords(6)
                txtnumofowners.Text = vehiclerecords(7)
                txtfueltype.Text = vehiclerecords(8)
                txttransmission.Text = vehiclerecords(9)
                sale.priceboughtfor = vehiclerecords(5) ' the price the vehicle was bought for is also stored in the sale details to calculate profits
            End If
            stringline = vehiiclereader.ReadLine()
        End While
        vehiiclereader.Close()
    End Sub
    Private Sub CBregistrationnum_Enter(sender As Object, e As EventArgs) Handles CBregistrationnum.Enter 'this reads the "Vehicledetails.txt" file and adds all the registration numbers to the combo box and allows staff to choose the required vehicle.
        Dim vehiiclereader As New System.IO.StreamReader(Dir$("Vehicledetails.txt"), True)
        CBregistrationnum.Items.Clear()
        stringline = vehiiclereader.ReadLine()
        While (stringline <> Nothing) '
            vehiclerecords = stringline.Split(",") 'this splits the vehicle records by ","
            CBregistrationnum.Items.Add(vehiclerecords(0))
            stringline = vehiiclereader.ReadLine()
        End While
        vehiiclereader.Close()
    End Sub
    Private Sub savebtn_Click_1(sender As Object, e As EventArgs) Handles savebtn.Click
        'saves the details of the vehicle sale to the "Saledetails.txt" file."

        Dim salewriter As New System.IO.StreamWriter(Dir$("Saledetails.txt"), True)
        'If the "Monthly payments" radio button is checked, the payment type is set to "monthly payments". Otherwise, the payment type is set to "full payment
        If RBmonthlypayments.Checked = True Then

            sale.paymenttype = "monthly payments"
        Else
            sale.paymenttype = "full payment"
        End If

        If CBcustomerID.Text = "" Then 'this is a presence check on the customer ID as it cannot be left blank, and as it is form a combo box no other validation is needed
            'If the customer ID is not provided, a message box is displayed to enter the customer ID, and the background color of the combo box is set to red.
            MsgBox("Please enter a customer ID")
            CBcustomerID.BackColor = Color.Red
        Else
            sale.customerID = CBcustomerID.Text
            CBcustomerID.BackColor = Color.Green
        End If

        If CBregistrationnum.Text = "" Then 'this is a presence check on the registration number as it cannot be left blank, and as it is form a combo box no other validation is needed
            MsgBox("Please enter a registration number")
            CBregistrationnum.BackColor = Color.Red
        Else
            sale.regnumber = CBregistrationnum.Text
            CBregistrationnum.BackColor = Color.Green
        End If

        If txtprice.Text = "" Then ' checks if the price is a integer, if not it isn't saved to the file.
            MsgBox("Please enter vehicle price")
            txtprice.BackColor = Color.Red
        ElseIf txtprice.Text <> "" Then
            If intcheck(txtprice.Text) Then
                txtprice.BackColor = Color.Green
                sale.vehicleprice = txtpriceVAT.Text
            Else
                txtprice.BackColor = Color.Red
                MsgBox("ERROR!" & vbCrLf & "The vehicle price cannot contain a non-number value")
            End If
        End If

        If CBpaymentmethod.Text = "" Then ' if the payment method is empty the fields won't save to the file.,
            MsgBox("Please enter payment method")
            CBpaymentmethod.BackColor = Color.Red
        Else
            sale.paymentmethod = CBpaymentmethod.Text
            CBpaymentmethod.BackColor = Color.Green
        End If


        sale.datebooked = DTPbookeddate.Text
        ' the fields are only saved to the file "Saledetails.txt" when all the text boxes are green,which shows that all the fields have passed validation checks
        If CBpaymentmethod.BackColor = Color.Green And txtpriceVAT.BackColor = Color.Green And CBregistrationnum.BackColor = Color.Green And CBcustomerID.BackColor = Color.Green Then

            salewriter.WriteLine(sale.staffID & "*" & sale.customerID & "*" & sale.regnumber & "*" & sale.vehicleprice & "*" & sale.datebooked & "*" & sale.paymentmethod & "*" & sale.paymenttype & "*" & sale.priceboughtfor)
            MsgBox("order saved")

            salewriter.Close()
        End If


    End Sub

    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click
        If Dir$("Temp.txt") = "" Then
            Dim st As New StreamWriter(Application.StartupPath & "\Temp.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            st.Close()
        End If

        Dim vehiclereader As New System.IO.StreamReader(Dir$("Vehicledetails.txt"), True)
        Dim sw As New System.IO.StreamWriter(Dir$("Temp.txt"), True)
        If CBpaymentmethod.BackColor = Color.Green And txtpriceVAT.BackColor = Color.Green And CBregistrationnum.BackColor = Color.Green And CBcustomerID.BackColor = Color.Green Then
            stringline = vehiclereader.ReadLine()
            While (stringline <> Nothing)

                vehiclerecords = stringline.Split(",") 'this splits the vehicle records by ","
                If (vehiclerecords(0) <> CBregistrationnum.Text) Then 'if the registration number is found
                    sw.WriteLine(stringline)
                    stringline = vehiclereader.ReadLine()
                Else
                    stringline = vehiclereader.ReadLine()
                End If

            End While

            vehiclereader.Close()
            sw.Close()

            File.Delete("Vehicledetails.txt") 'deletes vehicle file
            File.Move("Temp.txt", "Vehicledetails.txt") 're-create new vehicle file with edited record

        End If
    End Sub
    Private Sub calcbtn_Click(sender As Object, e As EventArgs) Handles calcbtn.Click 'this button calculates monthly cost of the veyhicle if the customer has chosen to pay it back monthly
        txtmonthlyfees.Text = Format((txtpriceVAT.Text - txtupront.Text) / txtpaymnetduration.Text, "currency")
    End Sub

    Private Sub CBcustomerID_Enter(sender As Object, e As EventArgs) Handles CBcustomerID.Enter
        Dim customerreader As New System.IO.StreamReader(Dir$("Customerdetails.txt"), True)
        CBcustomerID.Items.Clear()
        stringline = customerreader.ReadLine()
        While (stringline <> Nothing) '
            customerrecords = stringline.Split(",")
            CBcustomerID.Items.Add(customerrecords(0)) 'this adds the customer ID's to the combo box.
            stringline = customerreader.ReadLine()
        End While
        customerreader.Close()
    End Sub

    Private Sub CBcat_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBpaymentmethod.SelectedIndexChanged 'the staff chooses which payment method the customer has used, if they select card the payment scheme would be displayed
        If CBpaymentmethod.Text = "credit card" Then
            GBpaymenttype.Visible = True
        Else
            GBpaymenttype.Visible = False

        End If
    End Sub

    Private Sub RBfull_CheckedChanged(sender As Object, e As EventArgs) Handles RBfull.CheckedChanged 'if the customer wants to pay the for the vehicle in full they can.
        If RBmonthlypayments.Checked = True Then
            paymentscheme.Visible = True
        Else paymentscheme.Visible = False
        End If
    End Sub

    Private Sub RBmonthlypayments_CheckedChanged(sender As Object, e As EventArgs) Handles RBmonthlypayments.CheckedChanged 'if the customer wants to pay the vehicle in monthly instalments , the system would calculate the monthly payments by the custoemrs first payment.
        If RBmonthlypayments.Checked = True Then
            paymentscheme.Visible = True
        Else paymentscheme.Visible = False
        End If
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click 'this is takes the staff to the previous menu
        Me.Hide()
        Staffportal.Show()
    End Sub

    Private Sub txtprice_TextChanged(sender As Object, e As EventArgs) Handles txtprice.TextChanged
        txtpriceVAT.Text = Format(txtprice.Text * 1.2, "currency") 'this calculates the price of the vehicle after VAT
        If txtpriceVAT.Text = "" Then
            txtpriceVAT.BackColor = Color.Red
        End If
    End Sub
End Class