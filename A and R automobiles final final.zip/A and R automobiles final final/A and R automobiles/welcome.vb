﻿Imports System.IO
Public Class welcome
    Private Sub staffbtn_Click(sender As Object, e As EventArgs) Handles staffbtn.Click ' if it is a staff 
        Me.Hide()
        Staffportal.Show()
    End Sub

    Private Sub managerbtn_Click(sender As Object, e As EventArgs) Handles managerbtn.Click
        'these lines check if the password enetered by the manager is correct, if it is not correct they are denined acces to the manager portal.
        Dim pass As String
        pass = InputBox("Enter manager password")
        If pass = "master123" Then
            Me.Hide()
            managerportal.Show()
            MsgBox("Access granted")
        Else
            MsgBox("Access denied, manager password is incorrect", vbExclamation)
        End If
    End Sub


End Class
