﻿Imports System.IO
Public Class managerportal
    Private Sub staffdetails_Click(sender As Object, e As EventArgs) Handles staffdetails.Click 'allow the manager to access the staff details portal where the manager can add/edit/delete staff details.
        Me.Hide()
        managestaff.Show()

    End Sub

    ' this would allow the manager to view all the receipts of the vehicle ssales
    Private Sub receiptsbtn_Click(sender As Object, e As EventArgs) Handles receiptsbtn.Click
        Me.Hide()
        receipt.Show()
    End Sub
End Class