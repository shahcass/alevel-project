﻿Imports System.IO
Public Class vehicleinventory
    Dim vehiclereader As String


    ' this shows the staff all the vehicle the dealership has.
    Private Sub vehicleinventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim vehiclereader As New System.IO.StreamReader(Dir$("vehicledetails.txt"), True)

        lststock.View = View.Details
        lststock.GridLines = True
        lststock.FullRowSelect = True
        lststock.Scrollable = True
        ' these lines assign the headings for each coloumn
        lststock.Columns.Add("Registrtion number", 100)
        lststock.Columns.Add("Make", 100)
        lststock.Columns.Add("Model", 100)
        lststock.Columns.Add("Colour ", 100)
        lststock.Columns.Add("Mileage", 100)
        lststock.Columns.Add("Fuel type", 100)
        lststock.Columns.Add("Transmission type", 100)
        lststock.Columns.Add("Engine size", 100)
        lststock.Columns.Add("Number of owners", 100)
        lststock.Columns.Add("Existing problems", 100)
        lststock.Columns.Add("Price bought for", 100)


        stringline = vehiclereader.ReadLine()
        While (stringline <> Nothing)
            vehiclerecords = stringline.Split(",") 'split comma delimted fields into array
            line(0) = vehiclerecords(0) ' all these lines are assigned to each vehicle detail.
            line(1) = vehiclerecords(1)
            line(2) = vehiclerecords(2)
            line(3) = vehiclerecords(3)
            line(4) = vehiclerecords(4)
            line(5) = vehiclerecords(8)
            line(6) = vehiclerecords(9)
            line(7) = vehiclerecords(10)
            line(8) = vehiclerecords(7)
            line(9) = vehiclerecords(6)
            line(10) = vehiclerecords(5)


            stringline = vehiclereader.ReadLine() 'this adds all the vehicle details to the list view 
            stock = New ListViewItem(line)
            lststock.Items.Add(stock)
        End While
        vehiclereader.Close()
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click ' this button takes the staff to the previous 
        Me.Hide()
        Staffportal.Show()
    End Sub

    'this procedure outputs the makes of the vehicles in alphabetical order
    Private Sub sortbtn_Click(sender As Object, e As EventArgs) Handles sortbtn.Click
        Dim Index As Integer
        Dim vehicles(0 To 20) As vehicledetails
        Dim Temp As vehicledetails
        Dim Swapped As Boolean
        Dim itm As New ListViewItem
        Index = 0
        lststock.Clear()
        lststock.View = View.Details
        lststock.GridLines = True
        lststock.FullRowSelect = True
        'set the field headings
        lststock.Columns.Add("", 0)
        lststock.Columns.Add("Registrtion number", 100)
        lststock.Columns.Add("Make", 100)
        lststock.Columns.Add("Model", 100)
        lststock.Columns.Add("Colour ", 100)
        lststock.Columns.Add("Mileage", 100)
        lststock.Columns.Add("Fuel type", 100)
        lststock.Columns.Add("Transmission type", 100)
        lststock.Columns.Add("Engine size", 100)
        lststock.Columns.Add("Number of owners", 100)
        lststock.Columns.Add("Existing problems", 100)
        lststock.Columns.Add("Price bought for", 100)

        'populate array of records with unsorted customers
        Dim sr As New System.IO.StreamReader(Dir$("vehicledetails.txt"), True)
        vehiclereader = sr.ReadLine()

        Do
            vehiclerecords = vehiclereader.Split(",")
            vehicles(Index).regnumber = vehiclerecords(0)
            vehicles(Index).make = vehiclerecords(1)
            vehicles(Index).model = vehiclerecords(2)
            vehicles(Index).colour = vehiclerecords(3)
            vehicles(Index).mileage = vehiclerecords(4)
            vehicles(Index).price = vehiclerecords(5)
            vehicles(Index).problems = vehiclerecords(6)
            vehicles(Index).owners = vehiclerecords(7)
            vehicles(Index).fueltype = vehiclerecords(8)
            vehicles(Index).transmission = vehiclerecords(9)
            vehicles(Index).enginesize = vehiclerecords(10)

            Index = Index + 1
            vehiclereader = sr.ReadLine()
        Loop While (vehiclereader <> Nothing) '
        Index = Index - 1
        sr.Close()

        'perform bubble sort on vehicle engine sizeoutputing the vehicles in ascending order
        Do
            Swapped = False
            For I = 0 To (Index - 1)
                If (vehicles(I).enginesize > vehicles(I + 1).enginesize) Then 'If current  engine size is more than the next engine size in the array perform a swap operation
                    'method 1
                    Temp = vehicles(I) 'put next item in temp
                    vehicles(I) = vehicles(I + 1) 'put current item in next item
                    vehicles(I + 1) = Temp 'put next item in current item 
                    Swapped = True 'set swap flag to true to test another cycle
                End If
            Next

        Loop Until (Swapped = False) 'This line drops out of loop when there is no swap


        'this outputs all the records in order so that they match the list view coloumn.

        For i = 0 To Index
            itm = New ListViewItem()
            itm.SubItems.AddRange({"" & vehicles(i).regnumber, vehicles(i).make, vehicles(i).model, vehicles(i).colour, vehicles(i).mileage, vehicles(i).fueltype, vehicles(i).transmission, vehicles(i).enginesize, vehicles(i).owners, vehicles(i).problems, vehicles(i).price}) 'outputs the vehicle details in alphabetical order.
            lststock.Items.Add(itm)
        Next i
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Index As Integer
        Dim vehicles(0 To 20) As vehicledetails
        Dim Temp As vehicledetails
        Dim Swapped As Boolean
        Dim itm As New ListViewItem
        Index = 0
        lststock.Clear()
        lststock.View = View.Details
        lststock.GridLines = True
        lststock.FullRowSelect = True
        'sets the field headings of the list view
        lststock.Columns.Add("", 0)
        lststock.Columns.Add("Registrtion number", 100)
        lststock.Columns.Add("Make", 100)
        lststock.Columns.Add("Model", 100)
        lststock.Columns.Add("Colour ", 100)
        lststock.Columns.Add("Mileage", 100)
        lststock.Columns.Add("Fuel type", 100)
        lststock.Columns.Add("Transmission type", 100)
        lststock.Columns.Add("Engine size(L)", 100)
        lststock.Columns.Add("Number of owners", 100)
        lststock.Columns.Add("Existing problems", 100)
        lststock.Columns.Add("Price bought for", 100)

        'populate array of records with unsorted vehicles
        Dim sr As New System.IO.StreamReader(Dir$("vehicledetails.txt"), True)
        vehiclereader = sr.ReadLine()

        Do
            vehiclerecords = vehiclereader.Split(",")
            vehicles(Index).regnumber = vehiclerecords(0)
            vehicles(Index).make = vehiclerecords(1)
            vehicles(Index).model = vehiclerecords(2)
            vehicles(Index).colour = vehiclerecords(3)
            vehicles(Index).mileage = vehiclerecords(4)
            vehicles(Index).price = vehiclerecords(5)
            vehicles(Index).problems = vehiclerecords(6)
            vehicles(Index).owners = vehiclerecords(7)
            vehicles(Index).fueltype = vehiclerecords(8)
            vehicles(Index).transmission = vehiclerecords(9)
            vehicles(Index).enginesize = vehiclerecords(10)





            Index = Index + 1
            vehiclereader = sr.ReadLine()
        Loop While (vehiclereader <> Nothing)
        Index = Index - 1
        sr.Close()

        'performs bubble sort on vehicle mileage outputing the vehicles in ascending order, so that the lowest mileage is at the bottom
        Do
            Swapped = False
            For I = 0 To (Index - 1)
                If (vehicles(I).mileage > vehicles(I + 1).mileage) Then ''If current vehicle mileage is more than the next engine size in the array perform a swap operation
                    'method 1
                    Temp = vehicles(I) 'put next item in temp
                    vehicles(I) = vehicles(I + 1) 'put current item in next item
                    vehicles(I + 1) = Temp 'put next item in current item 
                    Swapped = True 'set swap flag to true to test another cycle
                End If
            Next

        Loop Until (Swapped = False) 'This line drops out of loop when there is no swap

        'this outputs all the records in order so that they match the list view coloumn.
        For i = 0 To Index
            itm = New ListViewItem()
            itm.SubItems.AddRange({"" & vehicles(i).regnumber, vehicles(i).make, vehicles(i).model, vehicles(i).colour, vehicles(i).mileage, vehicles(i).fueltype, vehicles(i).transmission, vehicles(i).enginesize, vehicles(i).owners, vehicles(i).problems, vehicles(i).price}) 'outputs the vehicle details in alphabetical order.
            lststock.Items.Add(itm)
        Next i
    End Sub


End Class