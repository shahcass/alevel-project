﻿Public Class bookingorreturn
    'this form allows the staff to chose what task they are doing, a rental retuen or a rental booking
    Private Sub vehicelrentalsbtn_Click(sender As Object, e As EventArgs) Handles vehicelrentalsbtn.Click 'allows access to the rental booking form
        Me.Hide()
        rentalform.Show()
    End Sub

    Private Sub rentalreturnbtn_Click(sender As Object, e As EventArgs) Handles rentalreturnbtn.Click 'allows access to the rental return form
        Me.Hide()
        Rentalreturn.Show()
    End Sub


End Class